<?php
// Simple PHP test - no dependencies
phpinfo();
