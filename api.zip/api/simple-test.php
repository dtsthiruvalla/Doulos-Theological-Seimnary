<?php
echo "PHP is working! Current time: " . date('Y-m-d H:i:s');
